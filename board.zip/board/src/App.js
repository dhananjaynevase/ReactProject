import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Fdlayout from './fdlayout/fdlayout.js';

class App extends Component {
  
  render() {
    return (
        <div className="">
        <Fdlayout/>
        <h4></h4>
      </div>
    );
  }
}

export default App;
console.log(Fdlayout);

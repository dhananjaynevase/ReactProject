import React,{Component} from 'react';
import './social.css';

const social= (props) =>{
    return(
        <div class="second">
           <div className="fb"><img src={props.src}/></div>
            <div className="content">
                <div className="one">
                <p className="hdr">{props.like}</p>
                <p className="para">{props.flo}</p>

            </div>
            <div className="two">
            <p className="hdr">{props.cmt}</p>
                <p className="para">{props.follow}</p>
            </div>
            </div>
        </div>
    )
}
export default social;
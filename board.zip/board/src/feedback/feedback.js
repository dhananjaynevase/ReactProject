import React, {Component} from 'react';
import './feedback.css'

const feedback =(props) =>{
    return(
        <div className="first">
            <div className={props.s}>
                <h2>{props.hd}</h2>
                 <span>{props.rt}</span>
                <img src={props.src}/>
                 <p>{props.dc}</p>
            </div>
        </div>
        )
}
export default feedback;
import React,{Component} from 'react';
import './gallery.css';

const gallery= (props) =>{
    return(
        <div  className="third">
            <h4>{props.gll}</h4>
           <div> <img height="270" width="270" src={props.src}/></div>
        </div>
    )
}
export default gallery;

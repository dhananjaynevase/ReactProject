import React, {Component} from 'react';
import Feedback from '../feedback/feedback.js';
import './fdlayout.css';
import Social from '../social/social.js';
import Gallery from '../gallery/gallery.js';
import Facebook from '../assets/images/facebook.png';
import Border from '../assets/images/br.png';
import Burger1 from '../assets/images/burger1.jpg';
import Burger2 from '../assets/images/burger2.jpg';
import Burger3 from '../assets/images/burger3.jpg';
import Burger4 from '../assets/images/burger4.jpg';
import Twitter from '../assets/images/twitter.png';
import Google from '../assets/images/google.png';


class fdlayout extends Component{
    state={
        title:"Gallery",
        one:[
          {header:"Today Visitors",value:"1,234k",brd:Border,desc:"This is testing page",cls:"clr1"},
          {header:"Today Sales",value:"5341",brd:Border,desc:"This is testing page",cls:"clr2"},
          {header:"Today Feedback",value:"324",brd:Border,desc:"This is testing page",cls:"clr3"},
          {header:"Today Earnings",value:"23,241",brd:Border,desc:"This is testing page",cls:"clr4"}
        ],
        two:[
          {icon:Facebook,likes:"42k",desc1:"Likes",comment:"90",desc2:"Friends"},
          {icon:Twitter,likes:"52k",comment:"70",desc1:"Tweats",desc2:"Followers"},
          {icon:Google,likes:"72k",comment:"15",desc1:"aaa",desc2:"frds"},
          {icon:Twitter,likes:"92k",comment:"99",desc1:"bbb",desc2:"follow"}        
        ],
      
        three:[
          {iconthree:Burger1},
          {iconthree:Burger2},
          {iconthree:Burger3},
          {iconthree:Burger4}
        ]
      }
 render(){
 return(
     <div className="container">
      <div>
          <Feedback hd={this.state.one[0].header} rt={this.state.one[0].value}src={this.state.one[0].brd}dc={this.state.one[0].desc} s={this.state.one[0].cls}></Feedback>
          <Feedback hd={this.state.one[1].header} rt={this.state.one[1].value}src={this.state.one[1].brd} dc={this.state.one[1].desc} s={this.state.one[1].cls}></Feedback>
          <Feedback hd={this.state.one[2].header} rt={this.state.one[2].value} src={this.state.one[2].brd}dc={this.state.one[2].desc} s={this.state.one[2].cls}></Feedback>
          <Feedback hd={this.state.one[3].header} rt={this.state.one[3].value}src={this.state.one[3].brd} dc={this.state.one[3].desc} s={this.state.one[3].cls}></Feedback>
      </div>
      <div>
          <Social src={this.state.two[0].icon} like={this.state.two[0].likes}flo={this.state.two[0].desc1} cmt={this.state.two[0].comment}follow={this.state.two[0].desc2}></Social>
          <Social src={this.state.two[1].icon} like={this.state.two[1].likes}flo={this.state.two[1].desc1} cmt={this.state.two[1].comment}follow={this.state.two[1].desc2}></Social>
          <Social src={this.state.two[2].icon} like={this.state.two[2].likes}flo={this.state.two[2].desc1} cmt={this.state.two[2].comment}follow={this.state.two[2].desc2}></Social>
          <Social src={this.state.two[3].icon} like={this.state.two[3].likes}flo={this.state.two[3].desc1} cmt={this.state.two[3].comment}follow={this.state.two[3].desc2}></Social>
      </div>
      <h4>{this.state.title }</h4>
      <div>
        <Gallery src={this.state.three[0].iconthree}></Gallery>
        <Gallery src={this.state.three[1].iconthree}></Gallery>
        <Gallery src={this.state.three[2].iconthree}></Gallery>
        <Gallery src={this.state.three[3].iconthree}></Gallery>
      </div>
    </div> 
 );
}
}
export default fdlayout;
